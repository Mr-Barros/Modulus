//
//  SoundManager.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 21/02/25.
//

import AVFoundation

class SoundManager {
    var player: AVAudioPlayer?
    var numberOfLoops: Int = 1
    
    func playSound(name: String, fileExtension: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: fileExtension) else { return }
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.numberOfLoops = numberOfLoops
            player?.play()
        } catch {
            print("Sound player error: \(error.localizedDescription)")
        }
    }
}
