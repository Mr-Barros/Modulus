//
//  Router.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 06/02/25.
//

enum Router {
    case menu
    case game
    case end
}
