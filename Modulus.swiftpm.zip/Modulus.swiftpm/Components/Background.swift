//
//  Background.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 22/02/25.
//

import SwiftUI

struct Background: View {
    var body: some View {
        ZStack {
            Color("Background")
            LinearGradient(
                colors: [Color("GradientBlue1"), Color("GradientBlue2")],
                startPoint: .bottom,
                endPoint: UnitPoint(x: UnitPoint.bottom.x, y: UnitPoint.bottom.y - 0.15))
                .opacity(0.6)
        }
    }
}

#Preview {
    Background()
}
