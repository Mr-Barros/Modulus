//
//  CGVector.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 16/02/25.
//

import CoreGraphics

extension CGVector {
    static func +(lhs: CGVector, rhs: CGVector) -> CGVector {
        return CGVector(dx: lhs.dx + rhs.dx, dy: lhs.dy + rhs.dy)
    }
    
    static func -(lhs: CGVector, rhs: CGVector) -> CGVector {
        return CGVector(dx: lhs.dx - rhs.dx, dy: lhs.dy - rhs.dy)
    }
    
    var length: CGFloat { hypot(self.dx, self.dy) }
    
    var angle: CGFloat { atan2(self.dy, self.dx) }
    
}
