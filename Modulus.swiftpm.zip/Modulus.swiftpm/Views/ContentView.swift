import SwiftUI

struct ContentView: View {
    #warning("Change to .menu")
    @State var router: Router = .menu
    @State var selectedCharacter: String = "lambda"
    
    @State var soundtrack = SoundManager()
    
    var body: some View {
        ZStack {
            switch router {
            case .menu:
                MenuView(router: $router, selectedCharacter: $selectedCharacter)
                    .transition(.opacity)
            case .game:
                GameView(router: $router, selectedCharacter: selectedCharacter)
                    .transition(.opacity)
            case .end:
                EndView(router: $router)
                    .transition(.opacity)
            }
        }
        .animation(.default, value: router)
        .onAppear {
            soundtrack.numberOfLoops = -1
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                #warning("Activate music")
                self.soundtrack.playSound(name: "MainTheme", fileExtension: ".mp3")
            }
        }
    }
}
