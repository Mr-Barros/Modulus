//
//  EndView.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 09/02/25.
//

import SwiftUI

struct EndView: View {
    @Binding var router: Router
    
    let dialogues: [String] = [
        "Yes! You did it! We're finally free!",
        "I must thank you for your bravery, my friend. I could have never done it on my own. You dashed through the dangers of Modulus and overcame the challenges of Linear Algebra like a true genius!",
         "I've heard legends of other mysterious worlds such as Modulus, each representing a different branch of Mathematics.",
         "In a way, our own reality follows the rules of Math. We just don't see it as clearly.",
         "Would you like to meet any of these new worlds? Well, they might be closer than you think. Start exploring and see what you stumble upon...",
         "Most importantly, you will be learning along the way. Learning how the world works. Learning new ways to change it. When you allow yourself to learn, Math will take you to places you could only dream of."
    ]
    @State var currentDialogueIndex: Int = 0
    
    @State var isGaussActive: Bool = true
    
    var body: some View {
        ZStack {
            Image("endBackground")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            if isGaussActive {
                HStack {
                    Text(dialogues[currentDialogueIndex])
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color("Background"))
                        .padding()
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .overlay {
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color("AccentColor"), lineWidth: 4)
                        }
                    
                    Image("gauss")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                }
                .frame(maxWidth: 650)
            } else {
                Image("endLabel")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 700)
                    .offset(x: 0, y: 180)
                VStack {
                    Spacer()
                    HStack(spacing: 150) {
                        ForEach(["mu", "lambda", "epsilon"], id: \.self) { name in
                            Image(name)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                        }
                    }
                }
            }
            
            
        }
        .onTapGesture {
            displayNextDialogue()
        }
    }
    
    func displayNextDialogue() {
        withAnimation {
            guard currentDialogueIndex + 1 < dialogues.count else {
                isGaussActive = false
                return
            }
            currentDialogueIndex += 1
        }
        
    }
}

#Preview {
    EndView(router: .constant(.end))
}
