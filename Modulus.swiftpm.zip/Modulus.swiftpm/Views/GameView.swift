//
//  GameView.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 06/02/25.
//

import SwiftUI
import SpriteKit

struct GameView: View {
    @Binding var router: Router
    @State var selectedCharacter: String
    
    var body: some View {
        ZStack {
            Background()
                .ignoresSafeArea()
            
            GeometryReader { proxy in
                SpriteView(
                    scene: GameScene(
                        size: proxy.size,
                        router: $router,
                        selectedCharacter: selectedCharacter),
                    options: [.allowsTransparency])
            }
        }
        .ignoresSafeArea()
    }
}

#Preview {
    GameView(router: .constant(.game), selectedCharacter: "mu")
}
