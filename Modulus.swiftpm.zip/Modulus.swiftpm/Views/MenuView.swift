//
//  MenuView.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 06/02/25.
//

import SwiftUI

struct MenuView: View {
    @Binding var router: Router
    @Binding var selectedCharacter: String
    
    var body: some View {
        ZStack {
            Background()
                .ignoresSafeArea()
            
            VStack {
                Spacer()
                HStack {
                    symbol(name: "ipad.landscape")
                    Spacer()
                    symbol(name: "speaker.wave.3.fill")
                }
            }
            
            VStack {
                Image("logo")
                    .resizable()
                    .scaledToFit()
                    .frame(minWidth: 640, minHeight: 224)
                    .padding(.horizontal, 128)
                    .padding(.top, 64)
                    .padding(.bottom, 32)
                     
                Spacer()
                
                Button {
                    router = .game
                } label: {
                    ZStack {
                        Image("startButton")
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 224)
                    }
                }
                .padding(.bottom, 86)
                
                Spacer()
                
                chooseYourCharacter
                    .padding(.bottom, 64)

            }
            
        }
    }
    
    func symbol(name: String) -> some View {
        Image(systemName: name)
            .font(.system(size: 64))
            .foregroundStyle(Color("LightBlue"))
            .fontWeight(.bold)
            .padding(.horizontal, 64)
            .padding(.vertical, 64)
    }
    
    var chooseYourCharacter: some View {
        VStack {
            HStack(spacing: 16) {
                characterView(name: "mu")
                characterView(name: "lambda")
                characterView(name: "epsilon")
            }
            Text("Choose your character")
                .font(.largeTitle)
                .foregroundStyle(.white)
                .fontWeight(.medium)
        }
    }
    
    func characterView(name: String) -> some View {
        VStack {
            Image(name)
                .resizable()
                .scaledToFit()
                .padding(.bottom, 4)
                .frame(minHeight: 112, maxHeight: 148)
                .offset(y: selectedCharacter == name ? -64 : 0)
            Rectangle()
                .fill(.white)
                .frame(height: 4)
            
        }
        .onTapGesture {
            withAnimation {
                selectedCharacter = name
            }
        }
        .frame(maxWidth: 186)
    }
}

#Preview {
    MenuView(router: .constant(.menu), selectedCharacter: .constant("lambda"))
}
