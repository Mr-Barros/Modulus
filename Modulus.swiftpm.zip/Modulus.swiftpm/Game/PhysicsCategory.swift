//
//  PhysicsCategory.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 09/02/25.
//

struct PhysicsCategory {
    static let none: UInt32 = 0x0
    static let player: UInt32 = 0x1 << 0
    static let platform: UInt32 = 0x1 << 1
    static let vector: UInt32 = 0x1 << 2
    static let modifier: UInt32 = 0x1 << 3
    static let checkpoint: UInt32 = 0x1 << 4
    static let matrix: UInt32 = 0x1 << 5
    static let specialMatrix: UInt32 = 0x1 << 6
}
