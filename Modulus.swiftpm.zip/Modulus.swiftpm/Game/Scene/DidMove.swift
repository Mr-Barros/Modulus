//
//  DidMove.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 22/02/25.
//

import SpriteKit

extension GameScene {
    override func didMove(to view: SKView) {
        anchorPoint = CGPoint(x: 0.5, y: 0.5)
        scaleMode = .aspectFill
        backgroundColor = .clear
        scene?.physicsWorld.contactDelegate = self
        
        camera = cameraNode
        addChild(cameraNode)
        
        cameraNode.addChild(player.hotbar)
        cameraNode.addChild(gauss)
        cameraNode.addChild(resetButton)

        addChild(hand)
        
        addChild(player)
        
        addChildren(platforms)
        addChildren(vectors)
        addChildren(modifiers)
        addChildren(checkpoints)
        addChildren(matrices)
        
        addChild(specialMatrix)
        
        drawGrid()
    }
    
    func addChildren(_ nodes: [SKNode]) {
        for node in nodes {
            addChild(node)
        }
    }
}
