//
//  Contacts.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 10/02/25.
//

import SpriteKit

extension GameScene {
    func didBegin(_ contact: SKPhysicsContact) {
        let bodyA = contact.bodyA
        let bodyB = contact.bodyB
        
        // Player and Vector
        if let vectorNode = (bodyA.node as? VectorNode) ?? (bodyB.node as? VectorNode),
            player == (bodyA.node as? PlayerNode) ?? (bodyB.node as? PlayerNode) {
            player.getImpulse(from: vectorNode)
        }
        
        // Player and Modifier
        if let modifierNode = (bodyA.node as? ModifierNode) ?? (bodyB.node as? ModifierNode),
            player == (bodyA.node as? PlayerNode) ?? (bodyB.node as? PlayerNode) {
            if player.collect(modifierNode) {
                removeChildren(in: [modifierNode])
                if tutorial == .collectOrb {
                    tutorialNext()
                }
            }
        }
        
        // Vector and Modifier
        if let vectorNode = (bodyA.node as? VectorNode) ?? (bodyB.node as? VectorNode),
            let modifierNode = (bodyA.node as? ModifierNode) ?? (bodyB.node as? ModifierNode) {
            vectorNode.receive(modifierNode)
            modifierNode.removeFromParent()
            
            if tutorial == .throwOrb
                || tutorial == .yCoord
                || tutorial == .length
                || tutorial == .angle
                || tutorial == .minus {
                
                tutorialNext()
            }
        }
        
        // Player and Checkpoint
        if let checkpointNode = (bodyA.node as? CheckpointNode) ?? (bodyB.node as? CheckpointNode), player == (bodyA.node as? PlayerNode) ?? (bodyB.node as? PlayerNode) {
            guard !checkpointNode.isActive else { return }
            checkpoint = checkpointNode.position
            for checkpoint in checkpoints {
                checkpoint.texture = SKTexture(imageNamed: "checkpointOff")
            }
            checkpointNode.activate()
        }
        
        // Player and Matrix
        if let matrixNode = (bodyA.node as? MatrixNode) ?? (bodyB.node as? MatrixNode), player == (bodyA.node as? PlayerNode) ?? (bodyB.node as? PlayerNode) {
            if !matrixNode.isActive {
                matrixNode.activate()
                for vector in self.vectors {
                    vector.multiply(by: matrixNode)
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + matrixNode.duration) {
                    matrixNode.deactivate()
                }
                
                if tutorial == .matrix {
                    tutorialNext()
                }
            }
        }
        
        // Player and Special Matrix
        if let specialMatrixNode = (bodyA.node as? SpecialMatrixNode) ?? (bodyB.node as? SpecialMatrixNode), player == (bodyA.node as? PlayerNode) ?? (bodyB.node as? PlayerNode) {
            specialMatrixNode.activate()
            
            endGame()
        }
        
    }
    
    func endGame() {
        let lightNode = SKShapeNode(rectOf: size)
        lightNode.position = .zero
        lightNode.fillColor = .white
        lightNode.strokeColor = .white
        lightNode.alpha = 0
        lightNode.zPosition = 1.0
        cameraNode.addChild(lightNode)
        
        let lightAction = SKAction.fadeAlpha(to: 1, duration: 2.0)
        lightNode.run(lightAction)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.router = .end
        }
    }
}
