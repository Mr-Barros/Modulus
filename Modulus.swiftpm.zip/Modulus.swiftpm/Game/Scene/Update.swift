//
//  Update.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 10/02/25.
//

import SpriteKit

extension GameScene {
    override func update(_ currentTime: TimeInterval) {
        cameraNode.position.x = player.position.x
        cameraNode.position.y = player.position.y + frame.height / 8
        
        player.update()
        
        tutorialUpdate()
        
        if fellOffTheWorld(player) {
            restoreCheckpoint()
        }
        
        for modifier in self.modifiers {
            if fellOffTheWorld(modifier) {
                modifier.physicsBody?.velocity = .zero
                modifier.position = modifier.originalPosition
            }
        }
        
    }
    
    func restoreCheckpoint() {
        player.physicsBody?.velocity = .zero
        player.position = checkpoint
        player.state = .idle
        
        for vector in self.vectors {
            vector.reset()
        }
        
        for modifier in self.modifiers where !player.hotbar.contains(modifier) {
            modifier.position = modifier.originalPosition
            if modifier.parent == nil {
                addChild(modifier)
            }
        }
        
        let hotbarModifiers = player.hotbar.retrieveAll()
        for modifier in hotbarModifiers {
            modifier.position = modifier.originalPosition
            if modifier.parent == nil {
                addChild(modifier)
            }
        }
    }
    
    func fellOffTheWorld(_ node: SKNode) -> Bool {
        return node.position.y < frame.minY - node.frame.height - 100
    }
    
    func tutorialUpdate() {
        if tutorial == .walk && player.isOnPlatform(1) && player.position.x > 250 {
            tutorialNext()
        }
        
        if tutorial == .gotoVector && player.position.y > 200 {
            tutorialNext()
        }
        
        if tutorial == .selectOrb && player.hotbar.selectedIndex == 0 {
            tutorialNext()
        }
        
        if tutorial == .walk && player.isOnPlatform(2) ||
            tutorial == .jump && player.isOnPlatform(2) ||
            tutorial == .vectorImpulse && player.isOnPlatform(3) ||
            tutorial == .gotoYCoord && player.isOnPlatform(4) ||
            tutorial == .gotoLength && player.isOnPlatform(5) ||
            tutorial == .gotoAngle && player.isOnPlatform(6) ||
            tutorial == .gotoMinus && player.isOnPlatform(7) ||
            tutorial == .gotoTwoModifiers && player.isOnPlatform(8) ||
            tutorial == .twoModifiers && player.isOnPlatform(9) {
            
            tutorialNext()
        }
        
        if tutorial == .gotoSpecialMatrix
            && player.isOnPlatform(10)
            && player.position.x > 7200 {
            
            tutorialNext()
        }
    }
}
