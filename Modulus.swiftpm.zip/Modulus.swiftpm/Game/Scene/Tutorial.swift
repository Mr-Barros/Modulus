//
//  Tutorial.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 18/02/25.
//

import SpriteKit

extension GameScene {
    enum TutorialState {
        case intro1
        case intro2
        case intro3
        case walk
        case jump
        case gotoVector
        case vectorImpulse
        case collectOrb
        case selectOrb
        case throwOrb
        case gotoYCoord
        case yCoord
        case gotoLength
        case length
        case gotoAngle
        case angle
        case gotoMinus
        case minus
        case gotoTwoModifiers
        case twoModifiers
        case matrix
        case gotoSpecialMatrix
        case specialMatrix1
        case specialMatrix2
        case end
    }
    
    func tutorialNext() {
        switch tutorial {
        case .intro1:
            tutorial = .intro2
            gauss.displayNextDialogue()
            
        case .intro2:
            tutorial = .intro3
            gauss.displayNextDialogue()
            
        case .intro3:
            tutorial = .walk
            hand.touch(at: CGPoint(x: 270, y: 30))
            gauss.displayNextDialogue()
            
        case .walk:
            tutorial = .jump
            hand.disappear()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.hand.touch(at: CGPoint(x: 350, y: 100))
            }
            
        case .jump:
            tutorial = .gotoVector
            hand.disappear()
            gauss.displayNextDialogue()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.hand.touch(at: CGPoint(x: 830, y: 30))
            }
            
        case .gotoVector:
            tutorial = .vectorImpulse
            hand.disappear()
            
        case .vectorImpulse:
            tutorial = .collectOrb
            hand.touch(at: CGPoint(x: 1060.0, y: 320.0))
            gauss.displayNextDialogue()
            
        case .collectOrb:
            tutorial = .selectOrb
            hand.disappear()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.hand.removeFromParent()
                self.player.hotbar.addChild(self.hand)
                self.hand.touch(at: CGPoint(x: 20.0, y: 60.0))
            }
            
        case .selectOrb:
            tutorial = .throwOrb
            hand.disappear()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.hand.removeFromParent()
                self.addChild(self.hand)
                self.hand.swipe(from: CGPoint(x: 1100, y: 350),
                                to: CGPoint(x: 1200, y: 600))
            }
            
        case .throwOrb:
            tutorial = .gotoYCoord
            hand.disappear()
            gauss.displayNextDialogue()
            
        case .gotoYCoord:
            tutorial = .yCoord
            gauss.displayNextDialogue()
            
        case .yCoord:
            tutorial = .gotoLength
            gauss.disappear()
            
        case .gotoLength:
            tutorial = .length
            gauss.displayNextDialogue()
            
        case .length:
            tutorial = .gotoAngle
            gauss.disappear()
            
        case .gotoAngle:
            tutorial = .angle
            gauss.displayNextDialogue()
            
        case .angle:
            tutorial = .gotoMinus
            gauss.disappear()
            
        case .gotoMinus:
            tutorial = .minus
            gauss.displayNextDialogue()
            
        case .minus:
            tutorial = .gotoTwoModifiers
            gauss.disappear()
            
        case .gotoTwoModifiers:
            tutorial = .twoModifiers
            gauss.displayNextDialogue()
            
        case .twoModifiers:
            tutorial = .matrix
            gauss.displayNextDialogue()
            
        case .matrix:
            tutorial = .gotoSpecialMatrix
            gauss.disappear()
            
        case .gotoSpecialMatrix:
            tutorial = .specialMatrix1
            player.state = .idle
            gauss.displayNextDialogue()
            gauss.run(SKAction.wait(forDuration: 2), withKey: "tutorialWait")
            
        case .specialMatrix1:
            tutorial = .specialMatrix2
            gauss.displayNextDialogue()
            
        case .specialMatrix2:
            tutorial = .end
            gauss.disappear()
            hand.touch(at: CGPoint(x: 7700, y: 650))
            
        case .end:
            hand.disappear()
            break
        }
    }
}
