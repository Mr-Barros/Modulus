//
//  Touches.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 10/02/25.
//

import SpriteKit

extension GameScene {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        
        initialTouchPoint = convert(location, to: cameraNode)
        isDragging = false
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        
        let currentTouchPoint = convert(location, to: cameraNode)
        if let initialTouchPoint {
            let distance = hypot(currentTouchPoint.x - initialTouchPoint.x,
                                 currentTouchPoint.y - initialTouchPoint.y)
            if distance > dragThreshold {
                isDragging = true
            }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        
        if tutorial == .intro1
            || tutorial == .intro2
            || tutorial == .intro3
            || tutorial == .specialMatrix1
            || tutorial == .specialMatrix2 {
            
            guard gauss.action(forKey: "tutorialWait") == nil else { return }
            tutorialNext()
            return
        }
        
        if nodes(at: location).contains(player.hotbar) {
            player.hotbar.selectModifier(at: convert(location, to: player.hotbar))
            return
        }
        
        if isDragging && player.hotbar.selectedIndex < player.hotbar.count {
            isDragging = false
            player.launchModifier(towards: location)
            
            return
        }
        
        if nodes(at: location).contains(resetButton) {
            restoreCheckpoint()
            return
        }
        
        if player.isTouching(PhysicsCategory.platform) {
            guard !isDragging else { return }
            
            if location.y >= player.position.y + player.size.height / 2 {
                player.jump(to: location.x)
            } else {
                player.startWalking(to: location.x)
            }
            
            if nodes(at: location).contains(hand) &&
                (tutorial == .walk || tutorial == .jump || tutorial == .collectOrb || tutorial == .gotoVector || tutorial == .end) {
                tutorialNext()
            }
        }
    }
}
