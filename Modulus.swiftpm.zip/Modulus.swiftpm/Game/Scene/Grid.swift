//
//  Grid.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 21/02/25.
//

import SpriteKit

extension GameScene {
    func drawGrid() {
        let spacing: CGFloat = 300
        let worldSize = CGSize(width: 10000, height: 3000)
        let rows = Int(worldSize.height / spacing) + 1
        let cols = Int(worldSize.width / spacing) + 1
        
        for row in -10..<rows {
            for col in -10..<cols {
                let position = CGPoint(x: CGFloat(col) * spacing, y: CGFloat(row) * spacing)
                addDot(at: position)
            }
        }
    }
    
    func addDot(at position: CGPoint) {
        let dot = SKShapeNode(circleOfRadius: 5)
        dot.position = position
        dot.fillColor = .white
        dot.strokeColor = .clear
        addChild(dot)
    }
}
