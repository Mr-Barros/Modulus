//
//  GameScene.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 06/02/25.
//

import SpriteKit
import SwiftUI

class GameScene: SKScene, SKPhysicsContactDelegate {
    @Binding var router: Router
    var selectedCharacter: String
    
    var cameraNode = SKCameraNode()
    
    var initialTouchPoint: CGPoint?
    var isDragging: Bool = false
    let dragThreshold: CGFloat = 10
    
    var checkpoint = CGPoint(x: 0, y: 150)
//    var checkpoint = CGPoint(x: 6900, y: 700)
        
    var tutorial: TutorialState = .intro1
    
    lazy var player = PlayerNode(
        imageNamed: selectedCharacter,
        hotbar: HotbarNode(position: CGPoint(x: frame.minX + 100, y: frame.midY)),
        position: checkpoint)
    
    lazy var gauss = GaussNode(position: CGPoint(x: frame.maxX - 100, y: frame.maxY - 180))
    
    lazy var hand = HandNode()
    
    let platforms: [PlatformNode] = [
        PlatformNode(id: 1, position: CGPoint(x: 100, y: 0), size: CGSize(width: 400, height: 5)),
        PlatformNode(id: 2, position: CGPoint(x: 650, y: 0), size: CGSize(width: 500, height: 5)),
        PlatformNode(id: 3, position: CGPoint(x: 1050, y: 300), size: CGSize(width: 300, height: 5)),
        PlatformNode(id: 4, position: CGPoint(x: 2050, y: 300), size: CGSize(width: 700, height: 5)),
        PlatformNode(id: 5, position: CGPoint(x: 1750, y: 825), size: CGSize(width: 500, height: 5)),
        PlatformNode(id: 6, position: CGPoint(x: 2150, y: 1100), size: CGSize(width: 500, height: 5)),
        PlatformNode(id: 7, position: CGPoint(x: 3300, y: 1200), size: CGSize(width: 600, height: 5)),
        PlatformNode(id: 8, position: CGPoint(x: 3950, y: 900), size: CGSize(width: 700, height: 5)),
        PlatformNode(id: 9, position: CGPoint(x: 5400, y: 600), size: CGSize(width: 600, height: 5)),
        PlatformNode(id: 10, position: CGPoint(x: 7200, y: 600), size: CGSize(width: 1200, height: 5))
    ]
    
    let vectors: [VectorNode] = [
        VectorNode(from: CGPoint(x: 820, y: 0), to: CGPoint(x: 820, y: 300)),
        VectorNode(from: CGPoint(x: 1200, y: 420), to: CGPoint(x: 1500, y: 420)),
        VectorNode(from: CGPoint(x: 2400, y: 300), to: CGPoint(x: 2100, y: 600)),
        VectorNode(from: CGPoint(x: 1500, y: 900), to: CGPoint(x: 1588, y: 988)),
        VectorNode(from: CGPoint(x: 2400, y: 1200), to: CGPoint(x: 2700, y: 900)),
        VectorNode(from: CGPoint(x: 3610, y: 1200), to: CGPoint(x: 4250, y: 1200)),
        VectorNode(from: CGPoint(x: 4310, y: 900), to: CGPoint(x: 4310, y: 1200)),
        
        VectorNode(from: CGPoint(x: 5700, y: 600), to: CGPoint(x: 5700, y: 900)),
        VectorNode(from: CGPoint(x: 6000, y: 600), to: CGPoint(x: 6000, y: 900)),
        VectorNode(from: CGPoint(x: 6300, y: 600), to: CGPoint(x: 6300, y: 900)),
    ]
    
    let modifiers: [ModifierNode] = [
        ModifierNode(effect: .xPlus, position: CGPoint(x: 1050, y: 400)),
        ModifierNode(effect: .yPlus, position: CGPoint(x: 2100, y: 400)),
        ModifierNode(effect: .rPlus, position: CGPoint(x: 1800, y: 860)),
        ModifierNode(effect: .counterClockwise, position: CGPoint(x: 2200, y: 1150)),
        ModifierNode(effect: .xMinus, position: CGPoint(x: 3500, y: 1250)),
        ModifierNode(effect: .rPlus, position: CGPoint(x: 3750, y: 1000)),
        ModifierNode(effect: .clockwise, position: CGPoint(x: 3900, y: 1000))
    ]
    
    let checkpoints: [CheckpointNode] = [
        CheckpointNode(position: CGPoint(x: 1850, y: 400)),
        CheckpointNode(position: CGPoint(x: 2100, y: 1200)),
        CheckpointNode(position: CGPoint(x: 4050, y: 1000)),
        CheckpointNode(position: CGPoint(x: 6900, y: 700)),
    ]
    
    let matrices: [MatrixNode] = [
        MatrixNode(a: 1, b: 1, c: 0, d: 1, position: CGPoint(x: 5400, y: 680))
    ]
    
    let specialMatrix = SpecialMatrixNode(position: CGPoint(x: 7700, y: 700))
    
    lazy var resetButton: SKSpriteNode = {
        let texture = SKTexture(imageNamed: "resetButton")
        let resetButton = SKSpriteNode(texture: texture)
        resetButton.setScale(0.25)
        resetButton.position = CGPoint(x: frame.minX + 100, y: frame.maxY - 100)
        return resetButton
    }()
    
    init(size: CGSize, router: Binding<Router>, selectedCharacter: String) {
        self.selectedCharacter = selectedCharacter
        self._router = router
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
