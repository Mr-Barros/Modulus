//
//  PlayerNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 09/02/25.
//

import SpriteKit

class PlayerNode: SKSpriteNode {
    var targetX: CGFloat = 0
    let walkSpeed: CGFloat = 250
    
    let hotbar: HotbarNode
    
    enum State {
        case idle
        case walking
        case jumping
        case impulse
    }
    var state: State = .idle
        
    init(imageNamed: String, hotbar: HotbarNode, position: CGPoint) {
        self.hotbar = hotbar
        let texture = SKTexture(imageNamed: imageNamed)
        super.init(texture: texture, color: .clear, size: texture.size())
        setScale(0.28)
        name = "player"
        
        applyPhysics()
        self.position = position
        self.zPosition = 0.0
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyPhysics() {
        physicsBody = SKPhysicsBody(texture: texture!, size: size)
        physicsBody?.affectedByGravity = true
        physicsBody?.isDynamic = true
        
        physicsBody?.allowsRotation = false
        physicsBody?.friction = 15.0
        physicsBody?.restitution = 0.0
        
        let weight: CGFloat = 0.045
        physicsBody?.density = (weight) / (physicsBody?.area ?? weight)
        
        physicsBody?.categoryBitMask = PhysicsCategory.player
        physicsBody?.contactTestBitMask = PhysicsCategory.vector | PhysicsCategory.modifier | PhysicsCategory.checkpoint | PhysicsCategory.matrix | PhysicsCategory.specialMatrix
        physicsBody?.collisionBitMask = PhysicsCategory.platform
    }
    
    func jump(to target: CGFloat) {
        state = .jumping
        
        physicsBody?.velocity.dx /= 2
        
        let dy: CGFloat = 25.0
        let maxDX: CGFloat = 12.0
        
        let dx = max(-maxDX, min(maxDX, (target - position.x) / 4))
        
        physicsBody?.applyImpulse(CGVector(dx: dx, dy: dy))
    }
    
    func startWalking(to target: CGFloat) {
        state = .walking
        targetX = target
                
        let oscillationDuration: TimeInterval = 0.2
        let oscillation = SKAction.sequence([
            SKAction.rotate(toAngle: 0.1, duration: oscillationDuration / 2),
            SKAction.rotate(toAngle: -0.1, duration: oscillationDuration / 2)
        ])
        let oscillationAction = SKAction.repeatForever(oscillation)
        
        run(oscillationAction, withKey: "oscillation")
    }
    
    func getImpulse(from vector: VectorNode) {
        guard self.action(forKey: "impulseWait") == nil else { return }
        state = .impulse
        
        let dx = vector.endPoint.x - position.x
        let dy = vector.endPoint.y - position.y
        
        physicsBody?.velocity = .zero
        
        let constantDX = 36 * dx / (abs(dx) + abs(dy))
        let constantDY = 36 * dy / (abs(dx) + abs(dy))
        
        physicsBody?.applyImpulse(CGVector(dx: dx / 14 + constantDX, dy: dy / 14 + constantDY))
        
        let waitAction = SKAction.wait(forDuration: 0.5)
        run(waitAction, withKey: "impulseWait")
    }
    
    func collect(_ modifier: ModifierNode) -> Bool {
        guard action(forKey: "launchWait") == nil,
                action(forKey: "collectWait") == nil else { return false }
        guard hotbar.append(modifier) else { return false }
        let waitAction = SKAction.wait(forDuration: 0.1)
        run(waitAction, withKey: "collectWait")
        return true
    }
    
    func launchModifier(towards location: CGPoint) {
        guard action(forKey: "launchWait") == nil else { return }
        
        let modifier = hotbar.getModifier()
        parent?.addChild(modifier)
        modifier.position = position
        
        let maxLaunchImpulse = 110.0
        let distanceX = location.x - position.x
        let distanceY = location.y - position.y
        
        let dx = maxLaunchImpulse * distanceX / (abs(distanceX) + abs(distanceY))
        let dy = maxLaunchImpulse * distanceY / (abs(distanceX) + abs(distanceY))
        
        let impulse = CGVector(dx: dx, dy: dy)
        
        let waitAction = SKAction.wait(forDuration: 1.0)
        run(waitAction, withKey: "launchWait")
        
        modifier.physicsBody?.applyImpulse(impulse)
    }
    
    func update() {
        switch state {
        case .walking:
            let distance = targetX - position.x
            if abs(distance) < 20.0 {
                state = .idle
                return
            }
            let direction: CGFloat = distance > 0 ? 1 : -1
            physicsBody?.velocity.dx = direction * walkSpeed
        case .idle, .jumping, .impulse:
            removeAction(forKey: "oscillation")
            zRotation = 0
            return
        }
    }
    
    func isTouching(_ category: UInt32) -> Bool {
        if let contactedBodies = physicsBody?.allContactedBodies(),
            contactedBodies.contains(where: { $0.categoryBitMask == category }) { return true }
        return false
    }
    
    func isOnPlatform(_ id: Int) -> Bool {
        guard let contactedBodies = physicsBody?.allContactedBodies() else { return false }
        return contactedBodies.contains(where: { $0.node?.name == "platform_\(id)" })
    }
    
}
