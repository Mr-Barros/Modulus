//
//  HandNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 14/02/25.
//

import SpriteKit

class HandNode: SKSpriteNode {
    
    private let appearAction = SKAction.fadeAlpha(to: 1, duration: 0.25)
    private let disappearAction = SKAction.fadeAlpha(to: 0, duration: 0.25)
    private let waitAction = SKAction.wait(forDuration: 1.0)
    private let pressAction = SKAction.scale(by: 0.6, duration: 0.1)
    private let releaseAction = SKAction.scale(to: 0.12, duration: 0.1)
    
    init() {
        let texture = SKTexture(imageNamed: "hand")
        super.init(texture: texture, color: .white, size: texture.size())
        setScale(0.12)
        name = "hand"
        
        alpha = 0
        zPosition = 0.9
        zRotation = .pi / 6
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func touch(at position: CGPoint) {
        self.position = position
        let loopAction = SKAction.repeatForever(SKAction.sequence([waitAction, pressAction, releaseAction]))
        let touchAction = SKAction.sequence([appearAction, loopAction])
        run(touchAction, withKey: "touch")
    }
    
    func swipe(from: CGPoint, to: CGPoint) {
        self.position = from
        
        let moveAction = SKAction.move(to: to, duration: 1.0)
        let returnAction = SKAction.move(to: from, duration: 1.5)
        let sequenceAction = SKAction.sequence([appearAction, pressAction, moveAction, releaseAction, disappearAction, returnAction])
        let swipeAction = SKAction.repeatForever(sequenceAction)
        run(swipeAction, withKey: "swipe")
    }
    
    func disappear() {
        removeAllActions()
        run(disappearAction) {
            self.setScale(0.12)
        }
    }
    
}
