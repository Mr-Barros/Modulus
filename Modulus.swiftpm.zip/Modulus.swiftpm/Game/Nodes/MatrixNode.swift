//
//  MatrixNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 23/02/25.
//

import SpriteKit

class MatrixNode: SKSpriteNode {
    let a: CGFloat
    let b: CGFloat
    let c: CGFloat
    let d: CGFloat
    var isActive = false
    
    let duration: CGFloat = 4.0
    
    init(a: CGFloat, b: CGFloat, c: CGFloat, d: CGFloat, position: CGPoint) {
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        let texture = SKTexture(imageNamed: "matrix")
        super.init(texture: texture, color: .clear, size: texture.size())
        self.position = position
        setScale(0.20)
        name = "matrix"
        zPosition = 0.3
        
        applyPhysics()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyPhysics() {
        physicsBody = SKPhysicsBody(texture: texture!, size: size)
        
        physicsBody?.affectedByGravity = false
        physicsBody?.isDynamic = true
        physicsBody?.allowsRotation = false
        
        physicsBody?.friction = 1.0
        
        physicsBody?.categoryBitMask = PhysicsCategory.matrix
        physicsBody?.contactTestBitMask = PhysicsCategory.player
        physicsBody?.collisionBitMask = PhysicsCategory.platform
    }
    
    func activate() {
        isActive = true
        let moveAction = SKAction.move(by: CGVector(dx: 0, dy: 150), duration: 0.5)
        run(moveAction)
    }
    
    func deactivate() {
        let moveAction = SKAction.move(by: CGVector(dx: 0, dy: -150), duration: 0.5)
        self.run(moveAction) {
            self.isActive = false
        }
    }
    
}
