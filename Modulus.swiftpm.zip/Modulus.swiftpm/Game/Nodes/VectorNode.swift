//
//  VectorNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 09/02/25.
//

import SpriteKit

class VectorNode: SKShapeNode {
    let basePoint: CGPoint
    var endPoint: CGPoint
    
    let originalEndPoint: CGPoint
    
    private let width: CGFloat = 5.0
    private let arrowSize: CGFloat = 20.0
        
    private var vector: CGVector { CGVector(dx: endPoint.x - basePoint.x, dy: endPoint.y - basePoint.y) }
    
    init(from basePoint: CGPoint, to endPoint: CGPoint) {
        self.basePoint = basePoint
        self.endPoint = endPoint
        self.originalEndPoint = endPoint
        
        super.init()
        name = "vector"
        
        let path = createVectorPath(width: width, length: vector.length, arrowSize: arrowSize)
        self.path = path
        
        fillColor = .white
        
        position = basePoint
        zPosition = -0.5
        zRotation = vector.angle
        
        applyPhysics(path)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createVectorPath(width: CGFloat, length: CGFloat, arrowSize: CGFloat) -> CGMutablePath {
        let path = CGMutablePath()
        path.move(to: CGPoint(x: 0.0, y: width / 2))
        path.addLine(to: CGPoint(x: length - arrowSize, y: width / 2))
        
        path.addLine(to: CGPoint(x: length - arrowSize, y: arrowSize / 2))
        path.addLine(to: CGPoint(x: length, y: 0.0))
        path.addLine(to: CGPoint(x: length - arrowSize, y: -arrowSize / 2))
        path.addLine(to: CGPoint(x: length - arrowSize, y: -width / 2))
        
        path.addLine(to: CGPoint(x: 0.0, y: -width / 2))
        path.closeSubpath()
        return path
    }
    
    func applyPhysics(_ path: CGPath) {
        physicsBody = SKPhysicsBody(edgeLoopFrom: path)
        physicsBody?.affectedByGravity = false
        physicsBody?.isDynamic = false
        
        physicsBody?.categoryBitMask = PhysicsCategory.vector
        physicsBody?.contactTestBitMask = PhysicsCategory.player | PhysicsCategory.modifier
        physicsBody?.collisionBitMask = PhysicsCategory.player
    }
    
    enum Rotation {
        case noRotation
        case counterClockwise
        case clockwise
    }
    
    func receive(_ modifier: ModifierNode) {
        var finalPoint = endPoint
        var rotation: Rotation = .noRotation
        
        switch modifier.effect {
        case .xPlus:
            finalPoint.x += modifier.value
        case .xMinus:
            finalPoint.x -= modifier.value
        case .yPlus:
            finalPoint.y += modifier.value
        case .yMinus:
            finalPoint.y -= modifier.value
        case .rPlus:
            finalPoint.x += modifier.value * cos(vector.angle)
            finalPoint.y += modifier.value * sin(vector.angle)
        case .rMinus:
            finalPoint.x -= modifier.value * cos(vector.angle)
            finalPoint.y -= modifier.value * sin(vector.angle)
        case .counterClockwise:
            rotation = .counterClockwise
            finalPoint.x = basePoint.x - vector.dy
            finalPoint.y = basePoint.y + vector.dx
        case .clockwise:
            rotation = .clockwise
            finalPoint.x = basePoint.x + vector.dy
            finalPoint.y = basePoint.y - vector.dx
        }
        
        let animateAction = animateVector(to: finalPoint, duration: 0.5, shapeNode: self, rotation: rotation)

        run(animateAction) {
            self.endPoint = finalPoint
            self.applyPhysics(self.path!)
        }
        
    }
    
    func multiply(by matrix: MatrixNode) {
        let newVector = CGVector(dx: matrix.a * vector.dx + matrix.b * vector.dy,
                                 dy: matrix.c * vector.dx + matrix.d * vector.dy)
        
        let finalPoint = CGPoint(x: basePoint.x + newVector.dx, y: basePoint.y + newVector.dy)
        
        let animateAction = animateVector(to: finalPoint, duration: 0.5, shapeNode: self, rotation: .noRotation)
        
        run(animateAction) {
            self.endPoint = finalPoint
            self.applyPhysics(self.path!)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + matrix.duration) {
            self.restore(to: self.originalEndPoint, rotation: .noRotation)
        }
        
    }
    
    func restore(to previousPoint: CGPoint, rotation: Rotation) {
        let reverseRotation: Rotation = switch rotation {
        case .noRotation:
            .noRotation
        case .counterClockwise:
            .clockwise
        case .clockwise:
            .counterClockwise
        }
        let reverseAnimation = animateVector(to: previousPoint, duration: 0.5, shapeNode: self, rotation: reverseRotation)
        run(reverseAnimation) {
            self.endPoint = previousPoint
            self.applyPhysics(self.path!)
        }
    }
    
    func reset() {
        endPoint = originalEndPoint
        path = createVectorPath(width: width, length: vector.length, arrowSize: arrowSize)
        zRotation = vector.angle
        applyPhysics(path!)
    }
    
    func animateVector(to finalPoint: CGPoint, duration: TimeInterval, shapeNode: SKShapeNode, rotation: Rotation) -> SKAction {
        var interpolatedPaths: [CGPath] = []
        var angles: [CGFloat] = []

        let frameCount = 60
        let finalLength = hypot(finalPoint.x - basePoint.x, finalPoint.y - basePoint.y)
        var finalAngle = atan2(finalPoint.y - basePoint.y, finalPoint.x - basePoint.x)
        
        if rotation == .counterClockwise && finalAngle < vector.angle {
            finalAngle += .pi * 2
        } else if rotation == .clockwise && finalAngle > vector.angle {
            finalAngle -= .pi * 2
        }
        
        for i in 0...frameCount {
            let newAngle: CGFloat = vector.angle + (finalAngle - vector.angle) * CGFloat(i) / CGFloat(frameCount)
            angles.append(newAngle)
            
            let newLength: CGFloat = vector.length + (finalLength - vector.length) * CGFloat(i) / CGFloat(frameCount)
            let newPath = createVectorPath(width: width, length: newLength, arrowSize: arrowSize)
            interpolatedPaths.append(newPath)
        }
        
        var frameIndex = 0
        let animateAction = SKAction.customAction(withDuration: duration) { node, elapsedTime in
            let progress = elapsedTime / duration
            frameIndex = min(Int(progress * CGFloat(frameCount)), frameCount - 1)
            (node as? SKShapeNode)?.path = interpolatedPaths[frameIndex]
            (node as? SKShapeNode)?.zRotation = angles[frameIndex]
        }
        
        return animateAction
    }
}

