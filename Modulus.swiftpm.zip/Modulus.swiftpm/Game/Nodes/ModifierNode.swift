//
//  ModifierNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 09/02/25.
//

import SpriteKit

class ModifierNode: SKSpriteNode {
    let originalPosition: CGPoint
    
    enum Effect: String {
        case xPlus
        case xMinus
        case yPlus
        case yMinus
        case rPlus
        case rMinus
        case counterClockwise
        case clockwise
    }
    let effect: Effect
    
    let value: CGFloat = 300
    
    init(effect: Effect, position: CGPoint) {
        self.effect = effect
        self.originalPosition = position
        let texture = SKTexture(imageNamed: effect.rawValue)
        super.init(texture: texture, color: .clear, size: texture.size())
        setScale(0.20)
        name = "modifier"
        
        applyPhysics()
        self.position = position
        zPosition = 0.4
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyPhysics() {
        physicsBody = SKPhysicsBody(texture: texture!, size: size)
        
        physicsBody?.affectedByGravity = true
        physicsBody?.isDynamic = true
        physicsBody?.allowsRotation = false
        
        physicsBody?.friction = 1.0
        
        physicsBody?.categoryBitMask = PhysicsCategory.modifier
        physicsBody?.contactTestBitMask = PhysicsCategory.player | PhysicsCategory.vector
        physicsBody?.collisionBitMask = PhysicsCategory.platform
    }
}
