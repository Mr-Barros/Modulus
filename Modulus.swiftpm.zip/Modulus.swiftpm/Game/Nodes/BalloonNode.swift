//
//  BalloonNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 13/02/25.
//

import SpriteKit
import SwiftUICore

class BalloonNode: SKShapeNode {
    private let label = SKLabelNode(fontNamed: "SFProText-Regular")
        
    init(text: String, isHighlighted: Bool = false) {
        super.init()
        
        label.text = text
        label.fontSize = 100
        label.fontColor = UIColor(Color("Background"))
        label.numberOfLines = 0
        label.preferredMaxLayoutWidth = 2000
        label.horizontalAlignmentMode = .center
        label.verticalAlignmentMode = .center
        
        let padding: CGFloat = 100
        let labelSize = label.frame.size
        let balloonSize = CGSize(width: labelSize.width + padding * 2, height: labelSize.height + padding * 2)
        let balloonOrigin = CGPoint(x: -balloonSize.width / 2, y: -balloonSize.height / 2)
        let cornerRadius: CGFloat = 100
        
        path = CGPath(
            roundedRect: CGRect(origin: balloonOrigin, size: balloonSize),
            cornerWidth: cornerRadius,
            cornerHeight: cornerRadius,
            transform: nil)
        
        fillColor = .white
        strokeColor = isHighlighted ? UIColor(Color.accentColor) : UIColor(Color("Background"))
        lineWidth = 20
        
        position = CGPoint(x: -balloonSize.width / 2 - 400, y: 0.0)
        zPosition = 0.1
        
        label.zPosition = 0.0
        
        addChild(label)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
