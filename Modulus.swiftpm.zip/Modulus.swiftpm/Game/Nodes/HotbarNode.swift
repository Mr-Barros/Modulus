//
//  HotbarNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 12/02/25.
//

import SpriteKit

class HotbarNode: SKSpriteNode, Collection {
    private var elements: [ModifierNode] = []
    private let maxSize: Int = 3
    private let slots: [SKSpriteNode] = [
        SKSpriteNode(texture: SKTexture(imageNamed: "slot"), color: .clear, size: CGSize(width: 80, height: 80)),
        SKSpriteNode(texture: SKTexture(imageNamed: "selectedSlot"), color: .clear, size: CGSize(width: 80, height: 80)),
        SKSpriteNode(texture: SKTexture(imageNamed: "slot"), color: .clear, size: CGSize(width: 80, height: 80))
    ]
    
    var selectedIndex: Int = 1
    
    var startIndex: Int { elements.startIndex }
    var endIndex: Int { elements.endIndex }
    
    func index(after i: Int) -> Int {
        return elements.index(after: i)
    }
    
    subscript(position: Int) -> ModifierNode {
        return elements[position]
    }
    
    init(position: CGPoint) {
        super.init(texture: nil, color: .clear, size: CGSize(width: 80, height: 240))
        slots[0].position = CGPoint(x: 0.0, y: slots[0].size.height)
        slots[1].position = CGPoint(x: 0.0, y: 0.0)
        slots[2].position = CGPoint(x: 0.0, y: -slots[2].size.height)
        addChild(slots[0])
        addChild(slots[1])
        addChild(slots[2])

        setScale(1.0)
        name = "hotbar"

        self.position = position
        self.zPosition = 0.5
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func append(_ element: ModifierNode) -> Bool {
        guard elements.count < maxSize else { return false }
        element.removeFromParent()
        
        elements.append(element)
        
        element.position.x = 0.0
        element.position.y = size.height / 2 - (size.height / 6) * (1 + 2 * CGFloat(elements.count - 1))
        
        element.zPosition = 0.6
        
        element.physicsBody = nil
        addChild(element)
        
        return true
    }
    
    func getModifier() -> ModifierNode {
        let element = elements[selectedIndex]
        element.applyPhysics()
        element.zPosition = 0.4
        removeChildren(in: [element])
        
        for i in selectedIndex + 1..<elements.count {
            elements[i].position.y += (size.height / 6) * 2
        }
        elements.remove(at: selectedIndex)
        return element
    }
    
    func selectModifier(at position: CGPoint) {
        
        let position = convert(position, to: self)
        if position.y > size.height / 6 {
            selectedIndex = 0
        } else if position.y > -size.height / 6 {
            selectedIndex = 1
        } else {
            selectedIndex = 2
        }
        for slot in slots {
            slot.texture = SKTexture(imageNamed: "slot")
        }
        slots[selectedIndex].texture = SKTexture(imageNamed: "selectedSlot")
    }
    
    func retrieveAll() -> [ModifierNode] {
        let modifiers = elements
        for element in elements {
            element.zPosition = 0.4
            element.applyPhysics()
        }
        removeChildren(in: elements)
        elements.removeAll()
        return modifiers
    }
}
