//
//  GaussNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 13/02/25.
//

import SpriteKit

class GaussNode: SKSpriteNode {
    private let dialogueBalloons: [BalloonNode] = [
        BalloonNode(text: "Hello, fellow mathematician! Welcome to Modulus, a world ruled by the laws of Linear Algebra! I suppose you don't know how you arrived here, do you?", isHighlighted: true),
        BalloonNode(text: "Well, neither do I, but I'm glad to have some company. I've been trapped here for... quite some time. Anyway, I'm Gauss, let me show you around!", isHighlighted: true),
        BalloonNode(text: "Oh, you want to escape? I don't think there's a way out of here, but I'll help you search. I reckon I don't have anything better to do...", isHighlighted: true),
        BalloonNode(text: "Follow me, let's take a walk. Tap where you want to go. You can jump by tapping high enough."),
        
        BalloonNode(text: "You've found a Vector, the most fundamental element of Modulus. If you touch it, it will boost you in the direction it's pointing. This allows you to reach new places."),
        BalloonNode(text: "You can use these shiny Orbs to change certain properties of vectors. Collect this one and launch it at that vector to see what it does."),
        BalloonNode(text: "The orb you launched just changed the vector's X Coordinate. Every vector has an x coordinate, which determines how far you're boosted horizontally."),
        BalloonNode(text: "You can also change a vector's Y Coordinate, which boosts you vertically. The x and y coordinates together make the vector's Cartesian Coordinates."),
        BalloonNode(text: "You can use some orbs to change a vector's Length, regardless of the direction it's pointing."),
        BalloonNode(text: "You can also spin a vector, changing its Angle with the x axis. A vector's length and angle together make its Polar Coordinates."),
        
        BalloonNode(text: "Orbs can increase or decrease vector coordinates, as well as spin them in both directions. You should know when to use each orb in your favor."),
        BalloonNode(text: "You can carry up to three orbs at a time, and use as many as you want with the same vector. Try throwing both at the vector on your right!"),
        
        BalloonNode(text: "Great, you've found a Matrix! This is a mysterious element that can alter all vectors at once. Touch it to see how it works!"),
        BalloonNode(text: "Wait a moment, what is that? It seems to be a 3 by 2 matrix...", isHighlighted: true),
        BalloonNode(text: "According to my calculations, it will transform each vector into a 3d vector. This could take us back to the real world!", isHighlighted: true)
    ]
    var currentDialogueIndex: Int = 0
    
    init(position: CGPoint) {
        let texture = SKTexture(imageNamed: "gauss")
        super.init(texture: texture, color: .clear, size: texture.size())
        setScale(0.25)
        name = "gauss"
        
        self.position = position
        zPosition = 0.7
        
        displayNextDialogue()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func displayNextDialogue() {
        alpha = 1.0
        hideDialogue()
        guard currentDialogueIndex < dialogueBalloons.count else { return }
        let balloon = dialogueBalloons[currentDialogueIndex]
        addChild(balloon)
        currentDialogueIndex += 1
    }
    
    private func hideDialogue() {
        dialogueBalloons.forEach { $0.removeFromParent() }
    }
    
    func disappear() {
        hideDialogue()
        alpha = 0.0
    }
    
    
    
}
