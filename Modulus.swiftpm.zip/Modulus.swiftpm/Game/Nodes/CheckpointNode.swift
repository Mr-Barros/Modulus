//
//  CheckpointNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 22/02/25.
//

import SpriteKit

class CheckpointNode: SKSpriteNode {
    var isActive: Bool = false
    
    init(position: CGPoint) {
        let texture = SKTexture(imageNamed: "checkpointOff")
        super.init(texture: texture, color: .clear, size: texture.size())
        setScale(0.2)
        name = "checkpoint"
        
        self.position = position
        self.zPosition = -0.2
        
        applyPhysics()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyPhysics() {
        physicsBody = SKPhysicsBody(texture: texture!, size: size)
        physicsBody?.affectedByGravity = true
        physicsBody?.isDynamic = true
        
        physicsBody?.categoryBitMask = PhysicsCategory.checkpoint
        physicsBody?.contactTestBitMask = PhysicsCategory.player
        physicsBody?.collisionBitMask = PhysicsCategory.platform
    }
    
    func activate() {
        isActive = true
        
        texture = SKTexture(imageNamed: "checkpointOn")
        
        let label = SKLabelNode(fontNamed: "SFProText-Bold")
        label.text = "Checkpoint"
        label.fontSize = 100
        label.fontColor = .white
        label.numberOfLines = 0
        
        label.position = CGPoint(x: 0.0, y: size.height / 2 + 250)
        label.alpha = 1.0
        label.setScale(0.25)
        
        addChild(label)
        
        let scale = SKAction.scale(to: 1.5, duration: 1.0)
        let fadeOut = SKAction.fadeOut(withDuration: 1.0)
        let groupAction = SKAction.group([scale, fadeOut])
        label.run(groupAction) {
            label.removeFromParent()
        }
    }
    
}
