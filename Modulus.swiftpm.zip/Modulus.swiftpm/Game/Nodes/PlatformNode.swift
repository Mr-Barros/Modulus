//
//  PlatformNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 09/02/25.
//

import SpriteKit

class PlatformNode: SKShapeNode {
    init(id: Int, position: CGPoint, size: CGSize) {
        super.init()
        
        let rect = CGRect(origin: CGPoint(x: -size.width / 2, y: -size.height / 2), size: size)
        path = CGPath(rect: rect, transform: nil)
        fillColor = .white
        name = "platform_\(id)"
        
        applyPhysics()
        self.position = position
        zPosition = -1.0
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyPhysics() {
        physicsBody = SKPhysicsBody(rectangleOf: frame.size)
        physicsBody?.affectedByGravity = false
        physicsBody?.isDynamic = false
        
        physicsBody?.categoryBitMask = PhysicsCategory.platform
        physicsBody?.contactTestBitMask = PhysicsCategory.player
        physicsBody?.collisionBitMask = PhysicsCategory.player | PhysicsCategory.modifier
    }
}
