//
//  SpecialMatrixNode.swift
//  Modulus
//
//  Created by Davi Martignoni Barros on 23/02/25.
//

import SpriteKit

class SpecialMatrixNode: SKSpriteNode {
    var isActive: Bool = false
    
    init(position: CGPoint) {
        let texture = SKTexture(imageNamed: "specialMatrix")
        super.init(texture: texture, color: .clear, size: texture.size())
        self.position = position
        name = "specialMatrix"
        setScale(0.20)
        zPosition = 0.3
        
        applyPhysics()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyPhysics() {
        physicsBody = SKPhysicsBody(texture: texture!, size: size)
        
        physicsBody?.affectedByGravity = false
        physicsBody?.isDynamic = true
        physicsBody?.allowsRotation = false
        
        physicsBody?.friction = 1.0
        
        physicsBody?.categoryBitMask = PhysicsCategory.specialMatrix
        physicsBody?.contactTestBitMask = PhysicsCategory.player
        physicsBody?.collisionBitMask = PhysicsCategory.platform
    }
    
    func activate() {
        isActive = true
        let moveAction = SKAction.move(by: CGVector(dx: 0, dy: 10), duration: 2.0)
        run(moveAction)
    }
}
